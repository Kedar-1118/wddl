import React, { useState, useEffect } from "react";
import Modal from "react-modal";
import ClipLoader from "react-spinners/ClipLoader";
import "tailwindcss/tailwind.css";

const API_URL = "https://swapi.dev/api/people/";
const SUPERHERO_API_KEY = "YOUR_SUPERHERO_API_KEY"; // Replace with your actual API key
const SUPERHERO_API_URL = `https://superheroapi.com/api/${SUPERHERO_API_KEY}/search/`;

Modal.setAppElement("#root");

const App = () => {
  const [characters, setCharacters] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [selectedCharacter, setSelectedCharacter] = useState(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [superheroImages, setSuperheroImages] = useState({}); // Store fetched images

  useEffect(() => {
    fetchCharacters(page);
  }, [page]);

  const fetchCharacters = async (page) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${API_URL}?page=${page}`);
      if (!res.ok) throw new Error("Failed to fetch characters");
      const data = await res.json();
      setCharacters(data.results);
      setTotalPages(Math.ceil(data.count / 10));

      // Fetch superhero images
      fetchSuperheroImages(data.results);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchSuperheroImages = async (characters) => {
    const images = {};
    await Promise.all(
      characters.map(async (char) => {
        try {
          const res = await fetch(`${SUPERHERO_API_URL}${char.name}`);
          if (!res.ok) throw new Error("Failed to fetch superhero image");
          const data = await res.json();

          if (data.response === "success" && data.results.length > 0) {
            images[char.name] = data.results[0].image.url; // Store image URL
          } else {
            images[char.name] = "https://via.placeholder.com/150"; // Fallback image
          }
        } catch {
          images[char.name] = "https://via.placeholder.com/150"; // Fallback image
        }
      })
    );
    setSuperheroImages(images);
  };

  const fetchHomeworld = async (url) => {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch homeworld");
      return await res.json();
    } catch {
      return null;
    }
  };

  const openModal = async (character) => {
    const homeworld = await fetchHomeworld(character.homeworld);
    setSelectedCharacter({ ...character, homeworld });
    setModalIsOpen(true);
  };

  return (
    <div className="flex flex-col items-center bg-teal-900 min-h-screen text-black p-4">
      <h1 className="text-3xl font-bold mb-6 text-white">Star Wars Characters</h1>
      {loading && <ClipLoader color="#fff" loading={loading} size={50} />}
      {error && <p className="text-red-500">{error}</p>}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 w-full max-w-6xl">
        {characters.map((char, index) => (
          <div
            key={char.name}
            className="p-6 rounded-lg shadow-lg cursor-pointer transform transition-transform duration-300 hover:scale-105 bg-orange-300 hover:bg-orange-400 bg-opacity-80 backdrop-blur-lg flex flex-col items-center"
            onClick={() => openModal(char)}
          >
            <img
              className="w-32 h-32 rounded-full shadow-md mb-4"
              src={superheroImages[char.name] || "https://via.placeholder.com/150"}
              alt={char.name}
            />
            <h1 className="text-3xl font-semibold text-center text-red-600">{char.name}</h1>
            <p className="opacity-60">Height: {char.height} cm</p>
            <p className="opacity-60">Mass: {char.mass} kg</p>
            <p className="opacity-60">Birth Year: {char.birth_year}</p>
          </div>
        ))}
      </div>
      <div className="flex justify-center items-center mt-6 space-x-4">
        <button
          className="px-4 py-2 bg-orange-500 rounded-lg disabled:opacity-50 text-white hover:bg-orange-800"
          disabled={page === 1}
          onClick={() => setPage(page - 1)}
        >
          Prev
        </button>
        <span>Page {page} of {totalPages}</span>
        <button
          className="px-4 py-2 bg-orange-500 rounded-lg disabled:opacity-50 text-white hover:bg-orange-800"
          disabled={page === totalPages}
          onClick={() => setPage(page + 1)}
        >
          Next
        </button>
      </div>
      <Modal
        isOpen={modalIsOpen}
        onRequestClose={() => setModalIsOpen(false)}
        className="bg-gray-800 p-6 rounded-lg max-w-md mx-auto text-white"
      >
        {selectedCharacter && (
          <div>
            <h2 className="text-2xl font-bold mb-2">{selectedCharacter.name}</h2>
            <p><strong>Height:</strong> {selectedCharacter.height / 100} m</p>
            <p><strong>Mass:</strong> {selectedCharacter.mass} kg</p>
            <p><strong>Birth Year:</strong> {selectedCharacter.birth_year}</p>
            <p><strong>Films:</strong> {selectedCharacter.films.length}</p>
            {selectedCharacter.homeworld && (
              <div className="mt-4">
                <h3 className="text-xl font-semibold">Homeworld: {selectedCharacter.homeworld.name}</h3>
                <p><strong>Terrain:</strong> {selectedCharacter.homeworld.terrain}</p>
                <p><strong>Climate:</strong> {selectedCharacter.homeworld.climate}</p>
                <p><strong>Residents:</strong> {selectedCharacter.homeworld.population}</p>
              </div>
            )}
            <button
              className="mt-4 px-4 py-2 bg-red-600 rounded-lg"
              onClick={() => setModalIsOpen(false)}
            >
              Close
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default App;
